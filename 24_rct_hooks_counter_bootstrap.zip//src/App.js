import "./styles.css";
import React, { useState } from "react";

export default function App() {
  const [count, setCount] = useState(0);
  return (
    <div className="App">
      <h1>
        Counter with <span className="title"> React Hooks</span>
      </h1>
      <h2>
        You clicked <span className="title">{count}</span> times!
      </h2>

      <button
        className="btn btn-primary obj"
        onClick={() => setCount(count + 1)}
      >
        +
      </button>
      <button
        className="btn btn-primary obj"
        onClick={() => setCount(count - 1)}
      >
        -
      </button>
    </div>
  );
}
